package modele;

public class Perchiste extends Zombie {

	private boolean aSaPerche;

	public Perchiste(int ligne, int x, Environnement e) {
		super(ligne, x,30,new GVieBasic(100),1, 1, e,new StrategiePerche(new StrategieLineaire()));
		this.aSaPerche=true;
	}

	public boolean getASaPerche(){
		return this.aSaPerche;
	}

	public void perdSaPerche(){
		this.aSaPerche=false;
	}

	public void attaquer(Perso p){

		p.getgVie().recoitDegat(this.getDegatsCauses(),this);

	}

}
