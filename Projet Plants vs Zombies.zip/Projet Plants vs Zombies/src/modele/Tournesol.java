package modele;

import java.util.Timer;
import java.util.TimerTask;

public class Tournesol extends Plante {
//Produit des soleils
	private Timer timerTournesol;
	public Tournesol(int ligne, int x, Environnement e) {
		super(ligne,80, x,0, e);
		
		timerTournesol = new Timer();
		timerTournesol.schedule(new TimerTask() {

			@Override
			public void run() {
				if(getgVie().estMort()){
					timerTournesol = null;
				}
				else{
					evolue();
				}
			}
		}, 4000, 5000+(int) (Math.random()*8000));
	}	

	@Override
	public void evolue() {
		this.getEnvironnement().ajoutPerso(new Soleil(this.getLigne(), this.getX()+(int)(Math.random()*75), this.getEnvironnement()));
	}

	
}