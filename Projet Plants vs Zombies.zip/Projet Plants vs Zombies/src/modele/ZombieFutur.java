package modele;

public class ZombieFutur extends Zombie {
	
	public ZombieFutur(int ligne, int x, Environnement e) {
		super(ligne, x,50,new GVieBasic(15),1, 10, e, new StrategieZombieFutur(new StrategieLineaire()));
	}
}
