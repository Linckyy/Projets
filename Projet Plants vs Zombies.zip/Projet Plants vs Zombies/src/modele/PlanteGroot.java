package modele;

public class PlanteGroot extends PlanteCorpsACorps{

	public PlanteGroot(int ligne, int x, Environnement e) {
		super(ligne,20, x, 1, e);
	}	

	@Override
	public void evolue() {
		for (Perso p : this.getEnvironnement().getLignePersos(this.getLigne())){
			if(this.estObstaclePour(p)){
				if(this.getX()+this.getLargeur() == p.getX()){
					attaquer(p);
				}
			}
		}
	}



	
}
