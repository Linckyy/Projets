package modele;

public class ZombieDeBase extends Zombie {
	
	public ZombieDeBase(int ligne, int x, Environnement e) {
		super(ligne, x,30,new GVieBasic(50),1, 1, e, new StrategieLineaire());
	}

}
