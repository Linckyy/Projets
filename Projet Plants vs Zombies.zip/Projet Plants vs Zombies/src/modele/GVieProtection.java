package modele;

public abstract class GVieProtection implements GestionnaireVie{

	public int pvArmure;
	public GVieBasic gVieBase;

	public GVieProtection(int pvArmure , GVieBasic gVieBasic){
		this.pvArmure=pvArmure;
		this.gVieBase=gVieBasic;
	}

	public abstract boolean efficaceContre (Perso p);

	
	public boolean estMort() {
		return this.gVieBase.estMort();
	}

	
	public void meurt(){
		this.gVieBase.meurt();
		this.pvArmure = 0;
	}

	public void recoitDegat(int degat, Perso p){
		if(this.efficaceContre(p)){
			degat/=2;
		}
		if ( this.getPvArmure()>0 ){
			if(degat > this.getPvArmure()){
					this.gVieBase.recoitDegat(degat-this.pvArmure,p);
					this.pvArmure = 0;
			}else{
				this.pvArmure-=degat;
			}
		}
		else {
			this.gVieBase.recoitDegat(degat,p);
		}
	}

	public int getVie(){
		return gVieBase.getVie()+this.getPvArmure();
	}

	public int getPvArmure(){
		return this.pvArmure;
	}

	@Override
	public boolean estSansArmure(){
		return this.pvArmure<=0;
	}
}
