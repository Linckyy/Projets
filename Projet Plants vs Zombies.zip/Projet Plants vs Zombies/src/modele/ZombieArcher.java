package modele;

public class ZombieArcher extends Zombie {

	int loop;
	public ZombieArcher(int ligne, int x, Environnement e) {
		super(ligne, x,30,new GVieBasic(50),1, 20, e, new StrategieLineaire());
		loop = 0;
	}
	
	@Override
	public void evolue() {
		loop++;
		if(loop >= 150){
			
			loop=0;
			tir();
		}
		
		Perso p = this.getDeplacement().faitDeplacer(this);
		if(p!=null){
			attaquer(p);
		}
	}

	
	
	
	private void tir() {
		this.getEnvironnement().ajoutPerso(new ProjectileFleche(this.getLigne(),this.getX()-10,this.getDegatsCauses()*2,this.getEnvironnement()));
	}

}

	
	






