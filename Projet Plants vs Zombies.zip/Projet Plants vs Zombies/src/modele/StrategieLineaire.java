package modele;

public class StrategieLineaire implements StrategieDeplacement {
	
	public StrategieLineaire(){}
	
	
	public Perso faitDeplacer(PersoMobile perso){

		for (Perso p : perso.getEnvironnement().getLignePersos(perso.getLigne())){
			if(p.estObstaclePour(perso)){
				if(p.getX()+p.getLargeur() > perso.getX()){
					if((p.getX()+p.getLargeur()) - (perso.getX()) < perso.getVitesse()){
						perso.setX((p.getX()+p.getLargeur()));
					}
				}
				if(p.getX()+p.getLargeur() == perso.getX() || (((perso instanceof Projectile && !(perso instanceof ProjectileFleche))&& perso.getX() >= p.getX() && perso.getX() <= p.getX()+p.getLargeur()))  ){
					return p;
				}
				
			}
		}
		perso.setX(perso.getX()-perso.getVitesse());
		return null;
	}
}
