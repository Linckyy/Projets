package modele;

public class Noix extends Plante{

	
	public Noix(int ligne, int x, Environnement e) {
		super(ligne,80,x,20,e);
	}

	@Override
	public void evolue() {
		//N'evolue pas
	}

	
}
