package modele;

import java.util.ArrayList;

public class Environnement {
	private int nbLigne;
	private int largeurJardin;
	private ArrayList<ArrayList<Perso>> lesPersos;
	private ArrayList<Soleil> lesSoleils;

	public Environnement(int largeurJardin, int nbLigne) {
		this.nbLigne = nbLigne;
		this.largeurJardin=largeurJardin;
		lesPersos = new ArrayList<ArrayList<Perso>>();
		for(int i=0; i < nbLigne; i++){
			lesPersos.add(new ArrayList<Perso>());
		}
		lesSoleils=new ArrayList<>();
	}

	public int getNbLigne() {
		return nbLigne;
	}


	public double getLargeurJardin() {
		return largeurJardin;
	}


	public void ajoutPerso(Perso p){
		if(p instanceof Soleil){
			lesSoleils.add((Soleil) p);
		}
		else{
			lesPersos.get(p.getLigne()).add(p);
		}
	}

	public int nbreLigne() {
		return nbLigne;
	}

	public ArrayList<Perso> getLignePersos(int i) {
		return lesPersos.get(i);
	}

	public ArrayList<Soleil> getSoleils() {
		return lesSoleils;
	}

	public void nettoyerMort() {
		for(int i=0; i<nbLigne;i++){
			ArrayList<Perso> lignePers= this.getLignePersos(i);
			for( int j = 0; j<lignePers.size();j++){
				Perso p = lignePers.get(j);
				if(p.getgVie().estMort() || p.getX() > this.largeurJardin || (p instanceof Projectile && p.getX() <0) ){
					lignePers.remove(j);
					j--;
				}
			}
		}
		nettoyerSoleil();
	}

	private void nettoyerSoleil(){
		for(int i=0; i<this.getSoleils().size();i++){
			Soleil s=this.getSoleils().get(i); 
			if(s.getgVie().estMort()){
				lesSoleils.remove(s);
			}
		}
	}
	
	//Test si un zombie est pr�sent � ces coordonn�es
	public boolean estPresent(int x,int y){
		for(int i=0; i<nbLigne;i++){
			ArrayList<Perso> lignePers= this.getLignePersos(i);
			for( int j = 0; j<lignePers.size();j++){
				Perso p = lignePers.get(j);
				if(p.getLigne() == y && p.getX() == x){
					return true;
				}
			}
		}
		return false;
	
	}
	
	public int getNbVivants(){
		int nb=0;
		for(ArrayList<Perso> list : this.lesPersos){
			for(Perso p: list){
				if(p instanceof Zombie){
						nb++;
				}
			}
		}
		return nb;
	}

	public boolean tousZombiesMort(){
		for(ArrayList<Perso> list : this.lesPersos){
			for(Perso p: list){
				if(p instanceof Zombie){
					if(!p.getgVie().estMort()){
						return false;
					}
				}
			}
		}
		return true;
	}

	public boolean aPerdu(){
		for(ArrayList<Perso> listPers : this.lesPersos){
			for(Perso p : listPers){
				if(p instanceof Zombie){
					if(p.getX()<0){

						return true;
					}
				}
			}
		}
		return false;
	}


}
