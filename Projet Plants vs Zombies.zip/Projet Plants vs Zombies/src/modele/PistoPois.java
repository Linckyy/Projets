package modele;

import java.util.Timer;
import java.util.TimerTask;

public class PistoPois extends Plante {
	private Timer timerProjectiles;
//Tire des projectile
	public PistoPois(int ligne, int x, Environnement e) {
		super(ligne,80, x, 30, e);
		timerProjectiles = new Timer();
		timerProjectiles.schedule(new TimerTask() {

			@Override
			public void run() {
				if(getgVie().estMort()){
					timerProjectiles = null;
				}
				else{
				evolue();
				}
			}
		}, 0, 2000);
	}	
	
	@Override
	public void evolue() {
		this.getEnvironnement().ajoutPerso(new Projectile(this.getLigne(),-7,this.getX()+65,this.getDegatsCauses(),this.getEnvironnement()));
	}


	
}
