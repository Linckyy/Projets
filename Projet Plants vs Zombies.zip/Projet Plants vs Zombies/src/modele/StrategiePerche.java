package modele;

public class StrategiePerche implements StrategieDeplacement {
	
	private StrategieLineaire strat = new StrategieLineaire();
	
	public StrategiePerche(StrategieDeplacement strat){
		
	}
	
	@Override
	public Perso faitDeplacer(PersoMobile perso){
		Perchiste persoPerchiste = (Perchiste) perso;
		Perso pObstacle=strat.faitDeplacer(persoPerchiste);
		if (pObstacle!=null && persoPerchiste.getASaPerche()){
			persoPerchiste.setX(persoPerchiste.getX()-pObstacle.getLargeur()-1);
			persoPerchiste.perdSaPerche();						
		} else {
			return pObstacle;
		}				
		return null;
		

	}
			
}		