package modele;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Jeu {

	private ArrayList<Zombie> reservoirZombie;
	private IntegerProperty cagnote = new SimpleIntegerProperty();
	private IntegerProperty nbZombiesRestant = new SimpleIntegerProperty();
	private Environnement environnement;
	private int numVague;


	public Jeu(int largeurLigne, int nbLigne) {
		reservoirZombie = new ArrayList<Zombie>();
		cagnote.set(150);
		environnement= new Environnement(largeurLigne,nbLigne);
		numVague = 0;
	}

	public Environnement getEnvironnement() {
		return environnement;
	}

	public boolean estFini() {
		return this.environnement.aPerdu() || (this.reservoirZombie.size() ==0 && this.environnement.tousZombiesMort());

	}

	public boolean aGagn�(){
		if(this.environnement.aPerdu()){
			return false;
		}
		return true;
	}


	public IntegerProperty nbZombiesRestantProperty() {
		return nbZombiesRestant;
	}

	public void unTour() {
		for(int i=0 ;i < environnement.nbreLigne();i++){
			ArrayList<Perso> listP=environnement.getLignePersos(i);
			for(int j=0; j < listP.size() ; j++){
				Perso p = listP.get(j);
				if(!(p instanceof PistoPois) && !(p instanceof Tournesol)){
					p.evolue();
				}
			}

		}		
		environnement.nettoyerMort();
		//Calcul nombre de zombies restant
		this.setNbZombieRestant(environnement.getNbVivants());
	}

	private void setNbZombieRestant(int nbVivants) {
		this.nbZombiesRestant.set(this.reservoirZombie.size()+nbVivants);
	}

	public void Initialisation2() {
		//Rempli reservoir
		remplirReservoir(2);


		System.out.println("INIT");

		//Spawn vagues zombies
		Timer timerSpanwnZombies = new Timer();
		timerSpanwnZombies.schedule(new TimerTask() {

			@Override
			public void run() {
				if(numVague < 2){
					lancerVague(1);
				}
				else {
					lancerVague((int) (Math.random()*3));
				}
				numVague++;
			}
		}, 10000, 8000+(int) Math.random()*10000);

	}

	private void remplirReservoir(int nbZombies){
		int percentZDB = 45; //De base
		int percentZC = 30; //Casque
		int percentZM = 20; //Moustiquaire
		int percentP = 10; //Perchiste
		int percentZA = 15; //Archers
		int percentZF = 100; //ZombiesFutur
		int percentZB = 100; //ZombiesBombe
		int nb;
		for(nb=nbZombies; nb> 0; nb--){
			double randomType = Math.random()*(percentP+percentZC+percentZDB+percentZM+percentZA+percentZF+percentZB);
			int randomLigne = (int) Math.round((Math.random()*(this.environnement.getNbLigne()-1)));

			if(randomType < percentZDB){
				reservoirZombie.add(new ZombieDeBase(randomLigne, (int)this.environnement.getLargeurJardin(), this.environnement));
			}
			else {
				if(randomType < percentZDB+percentZC){
					reservoirZombie.add(new ZombieCasque(randomLigne,(int)this.environnement.getLargeurJardin(),this.environnement));
				}
				else{
					if(randomType < (percentZDB+percentZC)+percentZM){
						reservoirZombie.add(new ZombieMoustiquaire(randomLigne,(int)this.environnement.getLargeurJardin(),this.environnement));
					}
					else{
						if(randomType < ((percentZDB+percentZC)+percentZM)+percentP){
							reservoirZombie.add(new Perchiste(randomLigne,(int)this.environnement.getLargeurJardin(),this.environnement));
						}
						else {
							if(randomType < ((percentZDB+percentZC)+percentZM)+percentP+percentZA){
								reservoirZombie.add(new ZombieArcher(randomLigne,(int)this.environnement.getLargeurJardin(),this.environnement));
							}
							else {
								if(randomType < ((percentZDB+percentZC)+percentZM)+percentP+percentZA+percentZF){
									reservoirZombie.add(new ZombieFutur(randomLigne,(int)this.environnement.getLargeurJardin(),this.environnement));
								}
								else{
									if(randomType < ((percentZDB+percentZC)+percentZM)+percentP+percentZA+percentZF+percentZB){
										reservoirZombie.add(new ZombieBombe(randomLigne,(int)this.environnement.getLargeurJardin(),this.environnement));
									}
								}
							}
						}
					}
				}
			}

		}
	}


	private void lancerVague(int nbZombies){
		int nbZombiesALancer=nbZombies;
		if(nbZombiesALancer > this.reservoirZombie.size()){
			nbZombiesALancer = this.reservoirZombie.size();

		}
		while(nbZombiesALancer > 0){
			environnement.ajoutPerso(reservoirZombie.get(0));
			this.reservoirZombie.remove(0);
			nbZombiesALancer--;
		}
	}


	public int getCagnote() {
		return cagnote.get();
	}

	public void setCagnote(int cagnote) {
		this.cagnote.set(cagnote);
	}

	public IntegerProperty cagnoteProperty() {
		return cagnote;
	}


}
