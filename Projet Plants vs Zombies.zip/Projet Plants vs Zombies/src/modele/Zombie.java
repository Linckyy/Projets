package modele;

public abstract class Zombie extends PersoMobile {
		
	public Zombie(int ligne, int x,int largeur,GestionnaireVie gVie,int vitesse, int dgt, Environnement e, StrategieDeplacement strat) {				
		super(ligne, x, largeur, dgt, gVie, vitesse, strat, e );
	}
	
	@Override
	public boolean estObstaclePour(Perso p){
		if (((p instanceof Zombie && ((Zombie) p).getVitesse() <= 0)) || p instanceof ProjectileFleche){
			return false;
		} else {
			return true;
		}
	}
	
	protected void attaquer(Perso p){
		p.getgVie().recoitDegat(this.getDegatsCauses(),this);
		if(p instanceof PlanteCactus){
			p.setDegatsCauses(this.getDegatsCauses());
			((PlanteCactus) p).attaquer(this);
		}
	}
}
