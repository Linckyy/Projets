﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Chronometre : MonoBehaviour {


	public float chrono;

	public bool gameover;
	public bool checkpointReached;

	public GameObject player;
	public Score score;
	//public GameObject camera;

	// Use this for initialization
	void Start () {
		player = GameObject.Find ("Perso");
		Time.timeScale = 1;
		//camera = Camera.main.gameObject;
		chrono = 10;
		gameover = false;
		checkpointReached = false;

		score = FindObjectOfType<Score> ();
		score.scoreCount = 0;
		score.scoreIncreasing = true;
	}
	
	// Update is called once per frame
	void Update () {
		
		chrono -= Time.deltaTime;

		if (chrono <= 0) {

			chrono = 0;
			gameover = true;
			Time.timeScale = 0;
			score.scoreIncreasing = false;
		} else if (player.transform.position.x <= -14) {
			gameover = true;
			Time.timeScale = 0;
			score.scoreIncreasing = false;

		}
	}

	public void OnGUI () {
		GUI.Box(new Rect(5,3,50,25), chrono.ToString("0"));

		if (gameover == true) {
			GUI.Box (new Rect (350, 150, 100, 25), "GAME OVER");
			GUI.Box (new Rect (310, 180, 180, 25), "Press 'R' to Restart");
			if (Input.GetKeyDown (KeyCode.R)) {
				SceneManager.LoadScene ("Scene1", LoadSceneMode.Single);
				//Application.LoadLevel ("Scene1");
			}

		}
		/*if (checkpointReached == true) {
			GUI.Box (new Rect (350, 150, 100, 25), "Checkpoint");
			checkpointReached = false;
		}*/
	}

}
