using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Respawn : MonoBehaviour {

	public GameObject[] obj;
	public float spawnMin = 2f;
	public float spawnMax = 3f;
	public int lol = 1;
	//public int rand = ;

	// Use this for initialization
	void Start () {
		

	}

	void Update() {
		Invoke ("Spawn", Random.Range (spawnMin, spawnMax));
	}
	
	// Update is called once per frame
	void Spawn () {
		

		if (lol%240 == 0) {
			Instantiate (obj[0], new Vector2(15, -5), Quaternion.identity);


		} if (lol % 70 == 0) {
			Instantiate (obj [1], new Vector2 (30, (Random.Range (-3, 0	))), Quaternion.identity);

		}
		if (lol % 570 == 0) {
			Instantiate (obj[2], new Vector2(-20, 0), Quaternion.identity);
		}

		if (lol % 1000 == 0) {
			Instantiate (obj[3], new Vector2(15, -4), Quaternion.identity);
		}
		lol++;
	}
	//Random.Range (1, obj.Length)
}
