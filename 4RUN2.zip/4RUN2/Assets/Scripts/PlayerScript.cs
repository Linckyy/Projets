﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {

	public float thrust = 1.0f;
	public Rigidbody2D rb;
	//private bool saut;
	private int jumps = 2;
	Animator animator;
	//public float reinit = 0.01f;
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		//saut = false;
		//rb.AddForce (transform.right * thrust);
		animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
	//	animator.SetInteger ("position",6);
		if (rb.velocity.y == 0) {
			//saut = false;
			jumps = 2;

		}
			
		if ((Input.GetKeyDown ("space") || Input.GetKeyDown ("up")) && jumps >= 1) {
			
			if (rb.velocity.y > 0) {
				//rb.velocity.y = 0.01f;
			}
			rb.AddForce (transform.up * thrust);
			//saut = true;
			jumps--;

		} 

	}
}