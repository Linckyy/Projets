﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drapeau : MonoBehaviour {

	public Chronometre chrono;
	// Use this for initialization
	void Start () {
		chrono.checkpointReached = false;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnTriggerEnter2D(Collider2D nimp) {
		if (nimp.tag == "Player") {
			chrono.chrono += 10;
			chrono.checkpointReached = true;
		}
	}
}
