Dans chaque PDF, il y a des lettres entre parenthèses a chaque fin de titre.
Ces lettres correspondent aux initiales de la personne qui a réalisé cette partie :
LM : Lorenso Mendes
MF : Melvyn Fariziala
MG : Melvin Gault
