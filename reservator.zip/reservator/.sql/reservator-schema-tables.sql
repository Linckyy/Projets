--------------------------------------------------------------
--        Script PostgreSQL.
--------------------------------------------------------------
drop schema reservator cascade;
create schema reservator;


/* NOTES:
 * - ajouter champ pour savoir si l'élève s'est présenté à la cantine.
 *
 */

--------------------------------------------------------------
-- Table: reservator.eleves
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.eleves(
        idCompte         serial,
        nom              Varchar (25) NOT NULL ,
        prenom           Varchar (25) NOT NULL ,
        identifiant      Varchar (25) NOT NULL ,
        motDePasse       Varchar (25) NOT NULL ,
        solde            Float NOT NULL ,
        idCompte_parents Int,
        IdGroupe         Int,
        constraint pk_eleves PRIMARY KEY (idCompte )
);


--------------------------------------------------------------
-- Table: reservator.parents
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.parents(
        idCompte        serial,
        nom             Varchar (25) NOT NULL ,
        prenom          Varchar (25) NOT NULL ,
        login           Varchar (25) NOT NULL ,
        motDePasse      Varchar (25) NOT NULL ,
        idCompte_eleves Int,
        constraint pk_parents PRIMARY KEY (idCompte )
);
INSERT INTO reservator.parents values(default,'NULL','NULL','NULL','admin');

--------------------------------------------------------------
-- Table: reservator.menus
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.menus(
        idMenu        serial,
        entree        Varchar (25) NOT NULL ,
        platPrincipal Varchar (25) NOT NULL ,
        dessert       Varchar (25) NOT NULL ,
        idCui         Int NOT NULL ,
        jour          date NOT NULL ,
        constraint pk_menus PRIMARY KEY (idMenu )
);


--------------------------------------------------------------
-- Table: reservator.cuisiniers
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.cuisiniers(
        idCui  serial,
        nom    Varchar (25) NOT NULL ,
        prenom Varchar (25) NOT NULL ,
        login  Varchar (25) NOT NULL ,
        pwd    Varchar (25) NOT NULL ,
        constraint pk_cuisiniers PRIMARY KEY (idCui )
);


--------------------------------------------------------------
-- Table: reservator.calendrier
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.calendrier(
        jour   Date NOT NULL ,
        idMenu Int ,
        constraint pk_calendrier PRIMARY KEY (jour )
);


--------------------------------------------------------------
-- Table: reservator.groupes
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.groupes(
        idGroupe  serial,
        classe    Varchar (25) NOT NULL ,
        nomGroupe Varchar (25),
        constraint pk_groupes PRIMARY KEY (IdGroupe )
);
INSERT INTO reservator.groupes values(default, 'Non assigné','');
INSERT INTO reservator.groupes values(default, 'seconde','');
INSERT INTO reservator.groupes values(default, 'premiere','');
INSERT INTO reservator.groupes values(default, 'terminale','');

--------------------------------------------------------------
-- Table: reservator.allergies
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.allergies(
        idAllerCa serial,
        nom       Varchar (32) NOT NULL ,
        constraint pk_allergies PRIMARY KEY (idAllerCa )
);

INSERT INTO reservator.allergies values(default,'gluten');
INSERT INTO reservator.allergies values(default,'crustacés');
INSERT INTO reservator.allergies values(default,'oeufs');
INSERT INTO reservator.allergies values(default,'poissons');
INSERT INTO reservator.allergies values(default,'arachides');
INSERT INTO reservator.allergies values(default,'soja');
INSERT INTO reservator.allergies values(default,'lait');
INSERT INTO reservator.allergies values(default,'fruits à coques');
INSERT INTO reservator.allergies values(default,'céleri');
INSERT INTO reservator.allergies values(default,'moutarde');
INSERT INTO reservator.allergies values(default,'graines de sésame');
INSERT INTO reservator.allergies values(default,'anhydride sulfureux');
INSERT INTO reservator.allergies values(default,'sulfites en concentration');
INSERT INTO reservator.allergies values(default,'lupin');
INSERT INTO reservator.allergies values(default,'mollusques');

--------------------------------------------------------------
-- Table: reservator.ingredients
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.ingredients(
        idIngr serial,
        nom    Varchar (25) NOT NULL ,
        constraint pk_ingredients PRIMARY KEY (idIngr )
);


--------------------------------------------------------------
-- Table: reservator.cantines
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.cantines(
        idCantine serial,
        nom       Varchar (25) ,
        capacite  Int ,
        constraint pk_cantines PRIMARY KEY (idCantine )
);

INSERT INTO reservator.cantines values(default,'Self du lycée',250);

--------------------------------------------------------------
-- Table: reservator.reservations
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.reservations(
        idCompte  Int NOT NULL ,
        jour      Date NOT NULL ,
        idCantine Int NOT NULL ,
	aEtePresent BOOLEAN,
        constraint pk_reservations PRIMARY KEY (idCompte ,jour ,idCantine )
);


--------------------------------------------------------------
-- Table: reservator.plagesHoraires
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.plagesHoraires(
        horaireDebut time NOT NULL ,
        horaireFin   time ,
        IdGroupe     int NOT NULL,
        jour         Date NOT NULL ,
        constraint pk_plagesHoraires PRIMARY KEY (IdGroupe ,jour )
);


--------------------------------------------------------------
-- Table: reservator.estDangereux
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.estDangereux(
        idIngr    Int NOT NULL ,
        idAllerCa Int NOT NULL ,
        constraint pk_estDangereux PRIMARY KEY (idIngr ,idAllerCa )
);


--------------------------------------------------------------
-- Table: reservator.possedeAllergies
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.possedeAllergies(
        idCompte  Int NOT NULL ,
        idAllerCa Int NOT NULL ,
        constraint pk_possedeAllergies PRIMARY KEY (idCompte ,idAllerCa )
);


--------------------------------------------------------------
-- Table: reservator.etreIngredient
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.etreIngredient(
        idIngr Int NOT NULL ,
        idMenu Int NOT NULL ,
        constraint pk_etreIngredient PRIMARY KEY (idIngr ,idMenu )
);


--------------------------------------------------------------
-- Table: reservator.virements
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.virements(
        montant         Float ,
        idCompte        Int NOT NULL ,
        idCompte_eleves Int NOT NULL ,
        constraint pk_virements PRIMARY KEY (idCompte ,idCompte_eleves )
);


--------------------------------------------------------------
-- Table: reservator.notes
--------------------------------------------------------------

CREATE TABLE IF NOT EXISTS reservator.notes(
        note     Int ,
        idCompte Int NOT NULL ,
        idMenu   Int NOT NULL ,
        constraint pk_notes PRIMARY KEY (idCompte ,idMenu )
);

ALTER TABLE reservator.eleves ADD CONSTRAINT FK_eleves_IdGroupe FOREIGN KEY (IdGroupe) REFERENCES reservator.groupes(IdGroupe);
ALTER TABLE reservator.menus ADD CONSTRAINT FK_menus_idCui FOREIGN KEY (idCui) REFERENCES reservator.cuisiniers(idCui);
ALTER TABLE reservator.menus ADD CONSTRAINT FK_menus_jour FOREIGN KEY (jour) REFERENCES reservator.calendrier(jour);
ALTER TABLE reservator.calendrier ADD CONSTRAINT FK_calendrier_idMenu FOREIGN KEY (idMenu) REFERENCES reservator.menus(idMenu);
ALTER TABLE reservator.reservations ADD CONSTRAINT FK_reservations_idCompte FOREIGN KEY (idCompte) REFERENCES reservator.eleves(idCompte);
ALTER TABLE reservator.reservations ADD CONSTRAINT FK_reservations_jour FOREIGN KEY (jour) REFERENCES reservator.calendrier(jour);
ALTER TABLE reservator.reservations ADD CONSTRAINT FK_reservations_idCantine FOREIGN KEY (idCantine) REFERENCES reservator.cantines(idCantine);
ALTER TABLE reservator.plagesHoraires ADD CONSTRAINT FK_plagesHoraires_IdGroupe FOREIGN KEY (IdGroupe) REFERENCES reservator.groupes(IdGroupe);
ALTER TABLE reservator.plagesHoraires ADD CONSTRAINT FK_plagesHoraires_jour FOREIGN KEY (jour) REFERENCES reservator.calendrier(jour);
ALTER TABLE reservator.estDangereux ADD CONSTRAINT FK_estDangereux_idIngr FOREIGN KEY (idIngr) REFERENCES reservator.ingredients(idIngr);
ALTER TABLE reservator.estDangereux ADD CONSTRAINT FK_estDangereux_idAllerCa FOREIGN KEY (idAllerCa) REFERENCES reservator.allergies(idAllerCa);
ALTER TABLE reservator.possedeAllergies ADD CONSTRAINT FK_possedeAllergies_idCompte FOREIGN KEY (idCompte) REFERENCES reservator.eleves(idCompte);
ALTER TABLE reservator.possedeAllergies ADD CONSTRAINT FK_possedeAllergies_idAllerCa FOREIGN KEY (idAllerCa) REFERENCES reservator.allergies(idAllerCa);
ALTER TABLE reservator.etreIngredient ADD CONSTRAINT FK_etreIngredient_idIngr FOREIGN KEY (idIngr) REFERENCES reservator.ingredients(idIngr);
ALTER TABLE reservator.etreIngredient ADD CONSTRAINT FK_etreIngredient_idMenu FOREIGN KEY (idMenu) REFERENCES reservator.menus(idMenu);
ALTER TABLE reservator.virements ADD CONSTRAINT FK_virements_idCompte FOREIGN KEY (idCompte) REFERENCES reservator.parents(idCompte);
ALTER TABLE reservator.virements ADD CONSTRAINT FK_virements_idCompte_eleves FOREIGN KEY (idCompte_eleves) REFERENCES reservator.eleves(idCompte);
ALTER TABLE reservator.notes ADD CONSTRAINT FK_notes_idCompte FOREIGN KEY (idCompte) REFERENCES reservator.eleves(idCompte);
ALTER TABLE reservator.notes ADD CONSTRAINT FK_notes_idMenu FOREIGN KEY (idMenu) REFERENCES reservator.menus(idMenu);

--------------------------------------------------------------
-- VUES ELEVE
--------------------------------------------------------------

CREATE VIEW vueCompteEleve AS select nom, prenom, solde from reservator.eleves where identifiant=current_user;
CREATE VIEW vueReservationsEleve AS select jour from reservator.reservations inner join reservator.eleves using (idCompte) where identifiant=current_user;


--------------------------------------------------------------
-- VUES PARENTS
--------------------------------------------------------------


CREATE VIEW vueReservationsAdmin AS select nom, prenom, jour from reservator.eleves inner join reservator.reservations using (idCompte);
CREATE VIEW scoreMenus AS select jour, entree, platPrincipal, dessert, avg(note) from reservator.menus inner join reservator.notes using (idMenu) group by jour,entree,platPrincipal,dessert;

--------------------------------------------------------------
-- VUES ADMIN
--------------------------------------------------------------
