GRANT connect ON DATABASE jcandela TO ahamdi;
GRANT usage ON SCHEMA reservator TO ahamdi;
GRANT select, insert, update, delete ON ALL TABLES IN SCHEMA reservator TO ahamdi;

GRANT connect ON DATABASE jcandela TO lmendes;
GRANT usage ON SCHEMA reservator TO lmendes;
GRANT select, insert, update, delete ON ALL TABLES IN SCHEMA reservator TO lmendes;

GRANT connect ON DATABASE jcandela TO afergoug;
GRANT usage ON SCHEMA reservator TO afergoug;
GRANT select, insert, update, delete ON ALL TABLES IN SCHEMA reservator TO afergoug;

GRANT connect ON DATABASE jcandela TO fplisson;
GRANT usage ON SCHEMA reservator TO fplisson;
GRANT select, insert, update, delete ON ALL TABLES IN SCHEMA reservator TO fplisson;
