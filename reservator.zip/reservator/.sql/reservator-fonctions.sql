DROP FUNCTION inscriptionRapide(Nom varchar, Prenom varchar, Email varchar, groupe varchar);
--DROP FUNCTION inscriptionComplete(Nom varchar, Prenom varchar, identifiant varchar, motDePasse varchar, solde float, IdGroupe int);
DROP FUNCTION modificationComptesEleves(Nom varchar, Prenom varchar, identifiant varchar, motDePasse varchar, solde float, IdGroupe int);


CREATE OR REPLACE FUNCTION inscriptionRapide(Nom varchar, Prenom varchar, email varchar, solde varchar,  groupe varchar) RETURNS varchar AS $$
	declare
		Identifiant varchar = left(Prenom, 1)||Nom;
		Nclasse int := 0;
	begin
		perform idgroupe from reservator.groupes where groupes.classe=groupe;
		if(FOUND) then
			Nclasse := (select idgroupe from reservator.groupes where groupes.classe=groupe);
		end if;
		insert into reservator.eleves values(default,lower(Nom),lower(Prenom),lower(Identifiant),email,motDePasse,0.0,1,Nclasse);
	end;
$$ LANGUAGE 'plpgsql';;


/*CREATE OR REPLACE FUNCTION inscriptionComplete(Nom varchar, Prenom varchar, solde float, classeEleve varchar) RETURNS varchar AS $$
	declare
		MotDePasse varchar =genererMotDePasse();
		Identifiant varchar = left(Prenom, 1)||Nom;
		Nclasse int := (select idGroupe from reservator.groupes where groupes.classe=lower(classeEleve));
	begin
			
		insert into reservator.eleves values(default,lower(Nom),lower(Prenom),lower(Identifiant),MotDePasse,0.0,1,idGroupe);
		return MotDePasse;
	end;
$$ LANGUAGE 'plpgsql';;*/


CREATE OR REPLACE FUNCTION modificationComptesEleves(Nom varchar, Prenom varchar, identifiant varchar, motDePasse varchar, solde float, classeEleve varchar) RETURNS varchar AS $$
	declare
		MotDePasse varchar =genererMotDePasse();
		Identifiant varchar = left(Prenom, 1)||Nom;
		IdGroupe int := (select idgroupe from reservator.groupes where groupes.classe=classeEleve);
		idCompteparents reservator.eleves.idCompte_parents%type;
	begin
			
		update reservator.eleves set nom=$1 where identifiant=$3;
		update reservator.eleves set motDePasse=$4 where identifiant=$3;		
		update reservator.eleves set solde=$5 where identifiant=$3;;
		update reservator.eleves set IdGroupe=IdGroupe where identifiant=$3;
		
		return 'Vos inforations ont été enregistrés';
	end;
$$ LANGUAGE 'plpgsql';;

