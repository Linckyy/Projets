<!DOCTYPE html>
<?php
	include("php/session.inc.php");
?>
<html> 
	<head>
		<meta charset= "UTF-8" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/styleReservation.css" />
		<link rel="stylesheet" href="css/styleindex.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/style.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/styleindex.css" />
		<title>Reservator</title>
	</head>

	<body>
		<?php
			include("parts/header.php");
		?>
		<section>
			<article>
				<br/>
				<h1>Information</h1>

				<p>Vous êtes étudiant, inscrit au lycée et à la recherche d'un meilleur moyen de gérer vos repas ? Vous êtes au bon endroit !
				Ici, vous allez pouvoir consulter les menus disponibles dans votre cantine, réserver une place au sein de celle-ci et réaliser
				tous les paiements nécessaires en toute simplicité ! Alors, qu'attendez-vous ? Rejoignez Reservator !</p>

			</article>

			<div id="inscriptionRapide">

				<h1>Inscription rapide</h1>

				<form name="Inscription" method="POST" action="php/inscriptionEleve.php">
					Nom : <input type="text" name="nom" required/>
					Prénom : <input type="text" name="prenom" required/>
					<p>Sélectionnez votre classe </p>
					<select name="classe">
						<option value="seconde"> Seconde</option>
						<option value="premiere"> Première</option>
						<option value="terminale"> Terminale</option>
					</select>
					<br/>
					<br/>
					Adresse mail : <input type="email" name="email" required/><BR/>
					<input type="submit" value="Envoyer"/>
				</form>
			</div>

		</section>
		<?
			include("parts/footer.php");
		?>
	</body>

</html>
