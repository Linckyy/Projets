
<!DOCTYPE html>
<?
	include("php/session.inc.php");
?>

<html> 
	<head>
		<meta charset= "UTF-8" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/styleinscription.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/style.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/styleinscription.css" />
		<title>Reservator</title>
	</head>

	<body>
		<?php
			include("parts/header.php");
		?>

		<section>
			<h1 id="h1">Inscription </h1>

			<div id="divInscription">

				<form id ="inscription" name="Inscription" method="POST" action="php/inscriptionEleve.php">
					Nom : <input type="text" name="nom" required/>
					Prénom : <input type="text" name="prenom" required/>
					<p>Sélectionnez votre classe </p>
					<select name="classe">
						<option value="seconde"> Seconde</option>
						<option value="premiere"> Première</option>
						<option value="terminale"> Terminale</option>
					</select>
					<br/>
					<br/>
					Adresse mail : <input type="email" name="email" required/>
					<br/>
					<p>Utilisateur de la base de données:</p>
					<select name="bdUtil">
						<option value="ahamdi">Amine HAMDI</option>
						<option value="fplisson">Florian PLISSON</option>
						<option value="jcandela">John CANDELA</option>
						<option value="afergoug">Abdelkader FERGOUG</option>
						<option value="lmendes"> Lorenso MENDES</option>
					</select>
					<br/>
					Mot de passe associé : <input type="password" name="bdMdp" required/>
					<input type="submit" value="Envoyer"/>
				</form>
			</div>

		</section>

		<footer>
			<a href="index.html"></a>
			<p>Reservator</p>
			<p>Tous droits réservés</p>
		</footer>
		
	</body>

</html>
