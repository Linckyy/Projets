<!DOCTYPE html>
<?
	include("php/session.inc.php");
?>
<html> 
	<head>
		<meta charset= "UTF-8" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/styleReservation.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/style.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/styleReservation.css" />
		<title>Reservator</title>
	</head>

	<body>
		<header>
			<div id="Menu">
				<nav id="MenuSite" >
					<ul>
						<li><a href="index.html"id="logo"><img src="img/logo_banderole_sans_fond.png" alt="vers l'index"></a></li>
						<li><a href="index.html" id="accueil">Accueil</a></li>
						<li><a href="menus.html" id="menus">Menus</a></li> 
						<li><a href="inscriptions.html" id="inscriptions">Inscription</a></li>
						<li><a href="connexion.html" id="connexion">Connexion</a></li>
						<li><a href="contact.html" id="contact">Contact</a></li>
					</ul>
				</nav>
			</div>
		</header>

		<!-- SECTION-->
		<section>
			<!--GAUCHE-->
			<div id="divGauche">
				<div id="informations">
					<p>La cantine sera fermée ce vendredi: plus d'essence</p>
				</div>
				
				<!--Bien nommer les boutons avec un nom de variable pour le PHP, pareil pour les méthodes + mettre la destination dans action-->
				<form method="POST" action="php/insertReservation.php">
					Date de reservation: <input type="date" name="reserve" placeholder="jj-mm-aaaa" />
					<div id="boutons">
						<input type="submit" value="Reserver">
						<input type="reset" value="Annuler">
					</div>
				</form>
			</div>
			
			
			<!--DROITE-->		
			<div id="divMenu">
				<h2>Menu du jour</h2>
				<div class="epd" id="entree">
					<p>melon</p>
					<p>OU</p>
					<p>salade de riz<p/>
				</div>
				
				<div class="epd" id="plat">
					<p>poisson</p>
					<p>OU</p>
					<p>steak haché</p>
				</div>
				
				<div class="epd" id="dessert">
					<p>flan</p>
					<p>OU</p>
					<p>yahourt</p>
				</div>
			</div>
		</section>
		<?
			include("parts/footer.php");
		?>
	</body>

</html>
