		<header>
			<div id="Menu">
				<nav id="MenuSite" >
					<ul>
						<li class="login" id="loginDev">
						<?php
							if(isset($_SESSION['bdUtil'])) {
								echo("Bonjour " . $_SESSION['bdUtil'] . " <a href='php/deconnexion.php?src=dev'>Se déconnecter</a>");
							}
							else {
								?>
									
									<form method="POST" action="php/enregistrementDev.php">
										<select name="bdUtil">
											<option value="jcandela">John CANDELA</option>
											<option value="ahamdi">Amine HAMDI</option>
											<option value="fplisson">Florian PLISSON</option>
											<option value="afergoug">Abdelkader FERGOUG</option>
											<option value="lmendes"> Lorenzo MENDES</option>
										</select>
										<input type="password" name="bdMdp" required placeholder="Mot de passe BD"/>
										<input type="submit" value="Envoyer"/>
									</form>
								<?php
							};
						?>
						</li>
						<li><a href="index.php"id="logo"><img src="img/logo_banderole_sans_fond.png" alt="vers l'index"></a></li>
						<li><a href="index.php" id="accueil">Accueil</a></li>
						<li><a href="menus.php" id="menus">Menus</a></li> 
						<li><a href="inscriptions.php" id="inscriptions">Inscription</a></li>
						<li><a href="connexion.php" id="connexion">Connexion</a></li>
						<li><a href="contact.php" id="contact">Contact</a></li>
						<li class="login" id="loginClient">
						<?php
							if(isset($_SESSION['Util'])) {
								echo("Bonjour " . $_SESSION['Util'] . " <a href='php/deconnexion.php?src=client'>Se déconnecter</a>");
							}
							else {
								?>
									<p>Vous n'êtes pas connecté. <a href="connexion.php">Se connecter?</a></p>
								<?php
							};
						?>						
						</li>
					</ul>
				</nav>
			</div>
		</header>