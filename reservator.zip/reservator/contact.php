<!DOCTYPE html>
<?
	include("php/session.inc.php");
?>
<html> 
	<head>
		<meta charset= "UTF-8" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/styleContact.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/style.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/styleContact.css" />
		<title>Reservator</title>
	</head>

	<body>
		<?php
			include("parts/header.php");
		?>

		<section>
			<h1>Contact</h1>
			<div id="quiSommeNous">
				<h1>Qui somme-nous?</h1>
				<p>C’est dans un espace entièrement réservé que sont accueillis les quelques 700 personnes, enfants comme adultes, qui déjeunent chaque jour à la cantine scolaire dont la capacité est de 450 places.</p>
					<figure>
  						<img src="img/refectoire.jpg" alt="refectoire" id="refectoire"/>
  						<figcaption>Isolée phoniquement, la salle de restauration a été équipée en matériel adapté.</figcaption>
					</figure>
					
				<p>La cantine est ouverte de 11h30 à 13h30 durant deux services distincts.</p>
				
					<figure>
  						<img src="img/equipe.jpg" alt="equipe" id="equipe"/>
  						<figcaption>Notre (super) équipe de cuisiniers.</figcaption>
					</figure>
			</div>
			
			<div id="nousContacter">
				<h1>Nous contacter</h1>
				<p>Pour plus d'informations, vous pouvez nous contacter grâce: </p>
				<ul>
					<li>au numero de l'établissement: 06.xx.xx.xx.xx ,</li>
					<li>à l'adresse mail de l'établissement: etablissement@etablissement.fr ,</li>
					<li>a l'adresse mail de la cantine: cantine@cantine.fr .</li>
				</ul>
				<p>Pour contacter le service de reservation en ligne: 06.xx.xx.xx.xx ou reservator@reservator.com .</p>
			</div>
		</section>

		<footer>
			<p>Reservator</p>
			<p>Tous droits réservés</p>
		</footer>
		
	</body>

</html>
