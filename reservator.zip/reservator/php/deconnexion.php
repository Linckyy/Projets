<?php
	include("session.inc.php");
	if($_GET['src']=="client") {
		logoutClient();
	}
	else {
		logout();
	}
	
	$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'connexion.php';
	header('Location: ./../' . $referer);
?>