<?php
	/*$req_select = "select inscriptionComplete('". $_POST['nom'] ."','". $_POST['prenom'] ."','". $_POST['identifiant'] ."','". $_POST['motDePasse'] ."','". $_POST['solde'] ."','". $_POST['IdGroupe'] ."' );";
	$dbconn = pg_connect($conn_string) or die("Connexion impossible");
	$result = pg_query($dbconn , $req_select);
	pg_close($dbconn);
	pg_free_result($result);
	header('Location: http://pageperso.iut.univ-paris8.fr/~jcandela/reservator/success.html');*/

	include("session.inc.php");
	include("bd.php");

	
	foreach ($_POST as $key => $value) {
		if(empty($value))
			$_POST[$key]="";
		else 
			$_POST[$key]=htmlspecialchars($value);
	}
	
	if(isset($_SESSION['bdUtil'])) {
		$bd=connexionBD();
		$req_select = "select modificationComptesEleves('". $_POST['nom'] ."','". $_POST['prenom'] ."','". $_POST['identifiant'] ."','". $_POST['motDePasse'] ."','". $_POST['solde'] ."','". $_POST['classeEleve'] ."' );";
		$result = $bd->query($req_select);
	}
	header('Location: http://pageperso.iut.univ-paris8.fr/~jcandela/reservator/success.html');
?>		