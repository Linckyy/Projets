<?php
	include("session.inc.php");
	include("bd.php");
	
	foreach ($_POST as $key => $value) {
		if(empty($value))
			$_POST[$key]="";
		else 
			$_POST[$key]=htmlspecialchars($value);
	}
	
	$mdp = sha1(uniqid());
	$req_select = "select inscriptionRapide('". $_POST['nom'] ."','". $_POST['prenom'] ."','". $_POST['email'] ."','" . $mdp . "','". $_POST['classe'] ."');";
	
	try {
		$bd=connexionBD();
		$bd->query($req_select);
		mail($_POST['email'], "Reservator: Email de confirmation",
			"Bonjour,
			Vous avez demandé la création d'un compte pour notre service,
			Afin de vous authentifier dans votre nouveau compte, voici les information nécessaire à votre connexion:
			Identifiant: " . strtolower(substr($_POST['prenom'], 0, 1) . $_POST['nom']) . "
			Mot de passe: " . $mdp . "
			N'hésitez pas à réinitialiser votre mot de passe dès que vous le pourrez.");
	}catch(Exception $e) {
		echo("Une erreur s'est produite. Renvoi vers la page lancée");
		sleep(3);
	}
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';
header('Location: ./../' . $referer);

?>