<?php
	include("session.inc.php");
	
	foreach ($_POST as $key => $value) {
		if(empty($value))
			$_POST[$key]="";
		else 
			$_POST[$key]=htmlspecialchars($value, ENT_COMPAT,'ISO-8859-1', true);
	}
	
	loginDev($_POST['bdUtil'], $_POST['bdMdp']);

$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';
header('Location: ./../' . $referer);
?>
