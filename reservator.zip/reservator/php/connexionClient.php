<?php
include("session.inc.php");

function connexionClient($login,$password) {
	if(isset($_SESSION['bdUtil']) && isset($_SESSION['bdMdp'])) {
		$bd = connexionBD();
		$result = $bd->prepare("SELECT identifiant, email, motdepasse from reservator.eleves where identifiant='" . $login . "' OR email='" . $login . "';");
		$result->execute();
		while($donnees = $result->fetch(PDO::FETCH_OBJ)) {
				$identifiant = $donnees->identifiant;
				$motdepasse = $donnees->motdepasse;
				$email = $donnees->email;
				if($motdepasse == $password && ($identifiant == $login || $email == $login)) {
					$_SESSION['Util']=$donnees->identifiant;
					$_SESSION['uID']=sha1(uniqid('',true).'_'.mt_rand());
				}
				return true;
		}
	}
}

foreach ($_POST as $key => $value) {
	if(empty($value))
		$_POST[$key]="";
	else 
		$_POST[$key]=htmlspecialchars($value);
}
	
connexionClient($_POST['identifiant'],$_POST['motDePasse']);
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'connexion.php';
header('Location: ./../' . $referer);
?>