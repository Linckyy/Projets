<?php

header('Content-Type: text/html; charset=utf-8');
define('INACTIVITY_TIMEOUT',300);
ini_set('session.use_cookies', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.use_trans_sid', false);

session_start();

include("bd.php");
	
function allIPs() {
	$ip = $_SERVER["REMOTE_ADDR"];
	   
	if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip=$ip.'_'.$_SERVER['HTTP_X_FORWARDED_FOR'];
	}
	
	if (isset($_SERVER['HTTP_CLIENT_IP'])) {
		$ip=$ip.'_'.$_SERVER['HTTP_CLIENT_IP'];
	}
    	
	return $ip;
}

function loginDev($login,$password) {
	$idBD=connexionBD1($login,$password);
	if($idBD!=null) {
		$_SESSION['bdUtil']=$login;
		$_SESSION['bdMdp']=$password;
		$_SESSION['devID'] = sha1(uniqid('',true).'_'.mt_rand());
		$_SESSION['ip']=allIPs();
		$_SESSION['expires_on']=time()+INACTIVITY_TIMEOUT;
	}
}

function checkLogin() {
	if (isset($_SESSION['expires_on'])) {
		if(time()>=$_SESSION['expires_on']) {
			logout();
		}
		else {
			$_SESSION['expires_on']=time()+INACTIVITY_TIMEOUT;
 		}
	}
}


function logout() {
	foreach ($_SESSION as $key => $value) {
		if(!empty($value)) {
			unset($_SESSION[$key]);
		}
	}
}

function logoutClient() {
	unset($_SESSION['Util']);
	unset($_SESSION['uID']);
}

checkLogin();
	
?>