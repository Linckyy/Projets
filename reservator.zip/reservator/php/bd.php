<?php
function connexionBD() {
		if(isset($_SESSION['bdUtil']) && isset($_SESSION['bdMdp'])) {
			try {
				$bd= new PDO('pgsql:host=database-etudiants;dbname=jcandela', $_SESSION['bdUtil'], $_SESSION['bdMdp']);
				return $bd;
			}catch(Exception $e) {
	
			}
		}
		return null;
}

function connexionBD1($login,$mdp) {
		$login=htmlspecialchars($login, ENT_COMPAT,'ISO-8859-1', true);
		$mdp=htmlspecialchars($mdp, ENT_COMPAT,'ISO-8859-1', true);
		if(isset($login) && isset($mdp)) {
			try {
				$bd= new PDO('pgsql:host=database-etudiants;dbname=jcandela', $login, $mdp);
				return $bd;
			}catch(Exception $e) {
	
			}
		}
		return null;
}

function recupererMenuDuJour() {
	$bd = connexion_bd();
	$bdDonnees= $bd->query("SELECT entree, platprincipal, dessert from reservator.menus inner join calendrier where jour=". date('Y-m-d').";");
	$bd=null;
	if($bdDonnees!=null) {
		return $bdDonnees;
	}
	else {
		return null;	
	}
}
?>