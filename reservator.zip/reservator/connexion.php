<!DOCTYPE html>
<?
	include("php/session.inc.php");
?>
<html> 
	<head>
		<meta charset= "UTF-8" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/styleconnexion.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/style.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/styleconnexion.css" />
		<title>Reservator</title>
	</head>

	<body>
		<?php
			include("parts/header.php");
		?>
		<section>
			<h1>Connexion</h1>
			</br>
			<?php
			if(!isset($_SESSION['Util'])) {
			?>
				<form name="Connexion" method="POST" id="connexion" action="php/connexionClient.php">
				Identifiant : <input type="text" name="identifiant" size="12"/>
				Mot de passe : <input type="password" name="motDePasse" size="12"/>
				<input type="submit" value="Connexion"/>
			</form>		
			<?php			
			}
			else {
				echo("<p align='center'>Vous êtes déjà connecté.</p>");	
			}
?>

		</section>
		<?
			include("parts/footer.php");
		?>	
	</body>

</html>
