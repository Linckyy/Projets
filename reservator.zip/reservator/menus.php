<!DOCTYPE html>
<?php
	include("php/session.inc.php");
	$date=null;
	if(isset($_POST['date'])) {
		$date=htmlspecialchars($_POST['date'], ENT_COMPAT,'ISO-8859-1', true);
	}
	if($date==null) {
		$date=date('Y-m-d');	
	}
	$menu=null;
	$bd=connexionBD();
	if($bd!=null) {
		$result = $bd->prepare("SELECT entree, platprincipal, dessert from reservator.menus where menus.jour='". $date . "';");
		$result->execute();
		$menu = $result->fetch(PDO::FETCH_ASSOC);
	}
	
	if($menu==null) {
		$menu["entree"]="Non défini";
		$menu["platprincipal"]="Non défini";
		$menu["dessert"]="Non défini";
	}
?>
<html> 
	<head>
		<meta charset= "UTF-8" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/styleMenus.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/style.css" />
		<link rel="stylesheet" media="screen and (max-width: 400px)" href="css/petiteResolution/styleMenus.css" />
		<link rel="stylesheet" href="css/styleReservation.css" />
		<title>Reservator</title>
	</head>
	<body>
		<?php
			include("parts/header.php");
		?>
		<section>
			<div id="divMenu">
				<h2>Menu du <?php echo($date);?></h2>
				<form method="POST" action="menus.php">
					<input type="date" name="date" placeholder="jj-mm-aaaa"/>
					<input type="submit" value="Envoyer"/>			
				</form>
				<div class="epd" id="entree">
					<p><h4>Entrée</h4><?php echo($menu["entree"]);?></p>
				</div>
				
				<div class="epd" id="plat">
					<p><h4>Plat</h4><?php echo($menu["platprincipal"]);?></p>
				</div>
				
				<div class="epd" id="dessert">
					<p><h4>Dessert</h4><?php echo($menu["dessert"]);?></p>
				</div>
			</div>
		</section>
		<?
			include("parts/footer.php");
		?>
	</body>
</html>
