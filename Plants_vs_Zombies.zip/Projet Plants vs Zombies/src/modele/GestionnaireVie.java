package modele;

public interface GestionnaireVie {

	
	public boolean estMort();
	public void meurt();
	public void recoitDegat(int degat,Perso p);
	public int getVie();
	public boolean estSansArmure();
}
