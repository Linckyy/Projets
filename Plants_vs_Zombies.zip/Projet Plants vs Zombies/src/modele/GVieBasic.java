package modele;

public class GVieBasic implements GestionnaireVie{
	
	public int pv;
	
	public GVieBasic(int pv){
		this.pv=pv;
	}
	
	public int getVie(){
		return pv;
	}
	
	public boolean estMort(){
		return this.pv <= 0;
	}
	
	public void meurt(){
		this.pv=0;
	}
	
	public void recoitDegat(int degat, Perso p){
			this.pv = pv - degat;
	}

	@Override
	public boolean estSansArmure() {
		return true;
	}
}
