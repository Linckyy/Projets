package modele;

public class GVieBouclier extends GVieProtection{

	public GVieBouclier(int pvArmure, GVieBasic gVieBasic) {
		super(pvArmure, gVieBasic);
	}


	@Override
	public boolean efficaceContre(Perso p) {
		if(p instanceof Projectile){
			return true;
		}
		return false;
	}

}
