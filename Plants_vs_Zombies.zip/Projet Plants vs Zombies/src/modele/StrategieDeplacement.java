package modele;

public interface StrategieDeplacement {
	Perso faitDeplacer(PersoMobile perso);
}
