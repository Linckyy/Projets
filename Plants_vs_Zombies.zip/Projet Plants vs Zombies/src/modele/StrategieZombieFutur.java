package modele;

import java.util.ArrayList;

public class StrategieZombieFutur implements StrategieDeplacement {

	private boolean ligneValide = false;
	private int tour;
	private StrategieLineaire strat;
	private int nouvelleLigne=-10;
	private int ancienneLigne=-10;

	public StrategieZombieFutur(StrategieDeplacement strat){
		this.tour=0;
		this.strat = new StrategieLineaire();
	}

	@Override
	public Perso faitDeplacer(PersoMobile perso){
		this.tour ++;
		ZombieFutur persoZF = (ZombieFutur) perso;
		Perso pObstacle=strat.faitDeplacer(persoZF);
		if (tour%180==0){
			do {
				this.ligneValide=true;
				this.ancienneLigne= persoZF.getLigne();
				this.nouvelleLigne = (int) (Math.round((Math.random()*(persoZF.getEnvironnement().getNbLigne()-1))));
				ArrayList<Perso> listePersoLigne = new ArrayList<Perso>();
				listePersoLigne = persoZF.getEnvironnement().getLignePersos(this.nouvelleLigne);


				for ( Perso p : listePersoLigne ){
					if ( (p.getX() < persoZF.getX()+persoZF.getLargeur() && 
							p.getX()+p.getLargeur() > persoZF.getX()+persoZF.getLargeur() ) || 
							(p.getX() < persoZF.getX() &&
									p.getX()+p.getLargeur() > persoZF.getX() )    ){
						ligneValide=false;
					}				
				}

			} while ( ligneValide == false);

			persoZF.getEnvironnement().getLignePersos(ancienneLigne).remove(persoZF);
			persoZF.setLigne(this.nouvelleLigne);
			persoZF.getEnvironnement().getLignePersos(nouvelleLigne).add(persoZF);

		}
		return pObstacle;	


	}


}	