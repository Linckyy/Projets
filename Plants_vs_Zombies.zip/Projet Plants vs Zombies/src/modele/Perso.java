package modele;

public abstract class Perso {

	private int ligne;
	private int x;
	private int largeur;
	private int degatsCauses;
	private Environnement environnement;
	private GestionnaireVie gVie;


	public Perso (int ligne, int x, int largeur , int dgt,GestionnaireVie gVie,Environnement e){
		this.ligne=ligne;
		this.x=x;
		this.largeur=largeur;
		this.degatsCauses=dgt;
		this.gVie = gVie;
		this.environnement = e;
	}


	public int getLigne() {
		return ligne;
	}

	public void setLigne(int ligne){
		this.ligne = ligne;
	}


	public int getX() {
		return x;
	}

	public void setX(int x){
		this.x = x;
	}

	public int getLargeur() {
		return largeur;
	}


	public int getDegatsCauses() {
		return degatsCauses;
	}

	public void setDegatsCauses(int dgt) {
		if(dgt >= 0)
			this.degatsCauses = dgt;
	}


	public GestionnaireVie getgVie() {
		return gVie;
	}



	public void setEnvironnement(Environnement environnement) {
		this.environnement = environnement;
	}


	public Environnement getEnvironnement() {
		return environnement;
	}



	public abstract void evolue();

	public abstract boolean estObstaclePour(Perso p);



}


