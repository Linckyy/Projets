package modele;

public abstract class Plante extends Perso{

	public Plante(int ligne,int largeur, int x, int degat,Environnement e) {
		super(ligne, x, largeur, degat, new GVieBasic(400), e);
	}

	@Override
	public boolean estObstaclePour(Perso p) {
		if(p instanceof Zombie || p instanceof ProjectileFleche){
			return true;
		}
		else {
			return false;
		}
	}

}
