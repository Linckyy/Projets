package modele;

public abstract class PersoMobile extends Perso {
	
	private int vitesse;
	private StrategieDeplacement deplacement;
	
	public PersoMobile(int ligne, int x, int largeur, int dgt, GestionnaireVie gVie, int vitesse, StrategieDeplacement strat, Environnement e) {
		super(ligne, x, largeur, dgt, gVie, e);
		this.vitesse=vitesse;
		this.deplacement=strat;
	}

	public int getVitesse() {
		return vitesse;
	}
	
	public void setVitesse(int vitesse) {
		this.vitesse = vitesse;
	}
	
	
	public StrategieDeplacement getDeplacement(){
		return deplacement;
	}
	
	public void setPosition(int pos){
		this.setX(pos);
	}
	
	public void changeDirection(){
		this.vitesse = -this.vitesse;
	}
	
	public void evolue(){	
		Perso p = this.getDeplacement().faitDeplacer(this);
			if(p!=null){
				attaquer(p);
			}
	}
	
	protected abstract void attaquer(Perso p);
	
	
	
	

}
