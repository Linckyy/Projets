package modele;

public class Projectile extends PersoMobile {
		
	public Projectile(int ligne,int vitesse, int x, int dgt, Environnement e) {				
		super(ligne, x, 15, dgt, new GVieBasic(100), vitesse, new StrategieLineaire(), e);
	}

	@Override
	public boolean estObstaclePour(Perso p){
		return false;
	}
	@Override
	public void attaquer(Perso p){
		p.getgVie().recoitDegat(this.getDegatsCauses(),this);
		this.getgVie().meurt();
	}

}
