package modele;

public class ZombieBombe extends Zombie {
	
	public ZombieBombe(int ligne, int x, Environnement e) {
		super(ligne, x,30,new GVieBasic(25),2, 10, e, new StrategieLineaire());
	}

	
	@Override
	protected void attaquer(Perso p){
		p.getgVie().meurt();
		this.getgVie().meurt();		
	}	
}