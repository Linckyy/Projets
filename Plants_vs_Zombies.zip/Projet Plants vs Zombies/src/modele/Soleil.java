package modele;

import java.util.Timer;
import java.util.TimerTask;

public class Soleil extends Perso{
	private boolean estRecupere;
	private int gain;
	
	public Soleil(int ligne, int x, Environnement e) {
		super(ligne, x, 30, 0, new GVieBasic(1), e);
		this.estRecupere=false;
		this.gain=25;
		Timer timerTournesol = new Timer();
		timerTournesol.schedule(new TimerTask() {
			
			@Override
			public void run() {
				evolue();
			}
		}, 20000);
	}

	@Override
	public void evolue() {
		this.getgVie().meurt();
	}

	@Override
	public boolean estObstaclePour(Perso p) {
		return false;
	}

	public boolean estRecupere() {
		return estRecupere;
	}

	public int getGain() {
		return gain;
	}


	
	
	
	

}
