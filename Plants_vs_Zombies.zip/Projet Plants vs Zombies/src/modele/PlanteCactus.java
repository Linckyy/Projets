package modele;

public class PlanteCactus extends PlanteCorpsACorps{
//Renvoi les d�gats qu'elle recoit
	public PlanteCactus(int ligne, int x, Environnement e) {
		super(ligne,80, x, 0, e);
	}	
	@Override
	public void evolue() {
		//n'evolue pas
	}
	
}
