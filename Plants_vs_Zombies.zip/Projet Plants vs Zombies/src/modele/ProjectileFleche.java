package modele;

public class ProjectileFleche extends Projectile {

	public ProjectileFleche(int ligne, int x, int dgt, Environnement e) {				
		super(ligne,7, x,dgt,e);
	}
	

}

