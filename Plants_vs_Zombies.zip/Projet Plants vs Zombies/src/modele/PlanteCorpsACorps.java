package modele;

public abstract class PlanteCorpsACorps extends Plante{

	public PlanteCorpsACorps(int ligne, int largeur, int x, int degat, Environnement e) {
		super(ligne, largeur, x, degat, e);
		// TODO Auto-generated constructor stub
	}

	
	protected void attaquer(Perso p){
		p.getgVie().recoitDegat(this.getDegatsCauses(),this);
	}


	@Override
	public abstract void evolue();

}
