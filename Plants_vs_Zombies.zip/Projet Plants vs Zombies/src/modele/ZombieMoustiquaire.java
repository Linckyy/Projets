package modele;

public class ZombieMoustiquaire extends Zombie {

	
	public ZombieMoustiquaire(int ligne, int x, Environnement e) {
		super(ligne, x,30,new GVieBouclier(25,new GVieBasic(50)),1, 10, e,new StrategieLineaire());

	}
}
