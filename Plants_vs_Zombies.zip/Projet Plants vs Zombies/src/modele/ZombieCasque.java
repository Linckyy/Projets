package modele;

public class ZombieCasque extends Zombie {
	
	public ZombieCasque(int ligne, int x, Environnement e) {
		super(ligne, x,30,new GVieBouclier(20,new GVieBasic(50)),1, 1, e, new StrategieLineaire());
	}



}
