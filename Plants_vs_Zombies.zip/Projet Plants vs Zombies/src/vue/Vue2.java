package vue;
import java.util.ArrayList;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import modele.Jeu;
import modele.Noix;
import modele.Perchiste;
import modele.Perso;
import modele.PistoPois;
import modele.PlanteCactus;
import modele.PlanteGroot;
import modele.Projectile;
import modele.ProjectileFleche;
import modele.Soleil;
import modele.Tournesol;
import modele.ZombieArcher;
import modele.ZombieBombe;
import modele.ZombieCasque;
import modele.ZombieDeBase;
import modele.ZombieFutur;
import modele.ZombieMoustiquaire;

public class Vue2 extends Application {

	private Jeu jeu;
	//Selection plantes
	private int planteAPlanter= -1;
	private int prixPlanteAPlanter;
	//Prix plantes
	private int prixPlante1 =100;
	private int prixPlante2 =75;
	private int prixPlante3 =50;
	private int prixPlante4 =50;
	private int prixPlante5 =50;

	private ArrayList<HBox> listBox = new ArrayList<HBox>();
	private BorderPane rootPrincipal = new BorderPane();
	private HBox menuTop = new HBox();
	private ImageView soleil = new ImageView("vue/soleil.png");
	private Label nbSoleil = new Label();
	private Button exit = new Button("Quitter");
	private VBox menuLeft = new VBox();

	//Affichage achat plantes
	private ImageView plante1= new ImageView("vue/peashooter.png");
	private HBox plante1Prix = new HBox();
	private ImageView plante1Soleil = new ImageView("vue/soleil.png");
	private Label plante1nbSoleil = new Label(""+prixPlante1);

	private ImageView plante2= new ImageView("vue/PlanteCactus.png");
	private HBox plante2Prix = new HBox();
	private ImageView plante2Soleil = new ImageView("vue/soleil.png");
	private Label plante2nbSoleil = new Label(""+prixPlante2);

	private ImageView plante3= new ImageView("vue/PlanteGroot.png");
	private HBox plante3Prix = new HBox();
	private ImageView plante3Soleil = new ImageView("vue/soleil.png");
	private Label plante3nbSoleil = new Label(""+prixPlante3);

	private ImageView plante4= new ImageView("vue/Sunflower.png");
	private HBox plante4Prix = new HBox();
	private ImageView plante4Soleil = new ImageView("vue/soleil.png");
	private Label plante4nbSoleil = new Label(""+prixPlante4);

	private ImageView plante5= new ImageView("vue/cherrybomb.png");
	private HBox plante5Prix = new HBox();
	private ImageView plante5Soleil = new ImageView("vue/soleil.png");
	private Label plante5nbSoleil = new Label(""+prixPlante4);

	//Text Win or Loose
	private Label nbZombiesRestant = new Label();
	private Label labZombesRestant = new Label("Nombre de zombies restant :");
	//METHODE DU MARGIN ENTRE LE MENU TOP ET LE TERRAIN
	private void extractedBorderPane(BorderPane rootPrincipal, HBox menuTop) {
		BorderPane.setMargin(menuTop, new Insets(5, 5, 10, 5));
	}
	private void extractedBorderPane(BorderPane rootPrincipal, VBox menuLeft) {
		BorderPane.setMargin(menuLeft, new Insets(5, 5, 10, 5));
	}
	private void extractedBorderPane(BorderPane rootPrincipal, Group root) {
		BorderPane.setMargin(root, new Insets(5, 0, 10, 0));
	}


	//METHODE DES MARGIN DU MENU DU HAUT
	private void extractedHBox(HBox menuTop, ImageView soleil) {
		HBox.setMargin(soleil, new Insets(5,2.5,10,10));
	}
	private void extractedHBox(HBox menuTop, Label nbSoleil) {
		HBox.setMargin(nbSoleil, new Insets(15,80,0,0));
	}
	private void extractedHBox(HBox menuTop, Button exit) {
		HBox.setMargin(exit, new Insets(15,10,0,0));
	}


	//METHODE DES MARGIN DU MENU DE GAUCHE
	private void extractedVBox(VBox menuLeft, ImageView plante1) {
		VBox.setMargin(plante1, new Insets(10,0,0,15));
	}




	@Override
	public void init() throws Exception {
		jeu      = new Jeu(900,5);
		jeu.Initialisation2();
		
		nbZombiesRestant.setFont(new Font(25));
		labZombesRestant.setFont(new Font(25));
		//Fait une liste de tous les prix
		listBox.add(plante1Prix);
		listBox.add(plante2Prix);
		listBox.add(plante3Prix);
		listBox.add(plante4Prix);
		listBox.add(plante5Prix);


		//bind nbsoleil sur cagnote
		nbSoleil.textProperty().bind(jeu.cagnoteProperty().asString());
		
		//bin nombre de zombies restant
		nbZombiesRestant.textProperty().bind(jeu.nbZombiesRestantProperty().asString());
	}


	public void start(Stage theStage) 
	{
		theStage.setTitle( "Plants VS Zombies" );

		Group root = new Group();

		//Background Terrain
		Image image = new Image("vue/Field.png");

		//Bouton Quitter
		exit.setOnAction(e -> arreterProgramme());
		//Stop quand quitte le programme
		theStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent t) {
				Platform.exit();
				System.exit(0);
			}
		});
		//Ajout des prix
		plante1Prix.getChildren().addAll(plante1Soleil,plante1nbSoleil);
		plante2Prix.getChildren().addAll(plante2Soleil,plante2nbSoleil);
		plante3Prix.getChildren().addAll(plante3Soleil,plante3nbSoleil);
		plante4Prix.getChildren().addAll(plante4Soleil,plante4nbSoleil);
		plante5Prix.getChildren().addAll(plante5Soleil,plante5nbSoleil);
		menuLeft.getChildren().addAll(plante1,plante1Prix,plante2,plante2Prix,plante3,plante3Prix,plante4,plante4Prix,plante5,plante5Prix);

		exit.setMinWidth(30);

		menuLeft.setMinWidth(70);
		plante1.setFitHeight(50);
		plante1.setFitWidth(60);

		plante2.setFitHeight(50);
		plante2.setFitWidth(60);

		plante3.setFitHeight(50);
		plante3.setFitWidth(60);

		plante4.setFitHeight(50);
		plante4.setFitWidth(60);

		plante5.setFitHeight(50);
		plante5.setFitWidth(60);



		menuTop.getChildren().addAll(soleil,nbSoleil,labZombesRestant,nbZombiesRestant,exit);
		
		//METHODE DES MARGIN DU MENU DU HAUT
		extractedHBox(menuTop, soleil);
		extractedHBox(menuTop, nbSoleil);
		extractedHBox(menuTop, nbZombiesRestant);
		extractedHBox(menuTop, labZombesRestant);
		extractedHBox(menuTop, exit);


		//METHODE DES MARGIN DU MENU DE GAUCHE
		extractedVBox(menuLeft, plante1);
		extractedVBox(menuLeft, plante2);
		extractedVBox(menuLeft, plante3);
		extractedVBox(menuLeft, plante4);
		extractedVBox(menuLeft, plante5);


		//Creation du terrain
		Canvas terrain = new Canvas( this.jeu.getEnvironnement().getLargeurJardin(), this.jeu.getEnvironnement().nbreLigne()*100);

		root.getChildren().addAll(new ImageView(image),terrain);
		rootPrincipal.setTop(menuTop); 
		rootPrincipal.setLeft(menuLeft); 
		rootPrincipal.setCenter(root);

		//METHODE DU MARGIN ENTRE LE MENU TOP ET LE TERRAIN
		extractedBorderPane(rootPrincipal, menuTop);

		//METHODE DU MARGIN ENTRE LE MENU LEFT ET LE TERRAIN
		extractedBorderPane(rootPrincipal,menuLeft);

		//METHODE DU MARGIN ENTRE LE MENU LEFT ET LE TERRAIN
		extractedBorderPane(rootPrincipal,root);

		Scene theScene = new Scene( rootPrincipal );
		theStage.setScene( theScene );


		//Si clique pour achat
		plante1.setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event){
				selectionnerPlante(0);

			}
		});
		plante2.setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event){
				selectionnerPlante(1);

			}
		});
		plante3.setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event){
				selectionnerPlante(2);

			}
		});

		plante4.setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event){
				selectionnerPlante(3);

			}
		});

		plante5.setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event){
				selectionnerPlante(4);

			}
		});

		//Si clique sur le terrain
		terrain.setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				double xPos = event.getX();
				double yPos = event.getY();

				//Si pas de plante � planter
				if(planteAPlanter == -1){
					//Si clique sur un soleil
					for (Soleil s: jeu.getEnvironnement().getSoleils()){
						if ((xPos>= s.getX()  && xPos <= s.getX()+s.getLargeur())  && (yPos>= s.getLigne()*100 && yPos<=s.getLigne()*100+s.getLargeur() )){
							s.estRecupere();
							s.getgVie().meurt();
							jeu.setCagnote(s.getGain()+jeu.getCagnote());
						}
					}
				}
				else {
					//Si une plante est � planter
					int x=(int) xPos; 
					int y=(int) yPos;

					planter(x,y);
				}

			}				
		}); 

		//BOUCLE D AFFICHAGE
		GraphicsContext gc = terrain.getGraphicsContext2D();


		Timeline gameLoop = new Timeline();
		gameLoop.setCycleCount( Timeline.INDEFINITE );

		KeyFrame kf = new KeyFrame(
				Duration.seconds(0.017),                
				new EventHandler<ActionEvent>()
				{
					public void handle(ActionEvent ae)
					{
						if(jeu.estFini()) {
							gameLoop.stop();
							nbSoleil.textProperty().unbind();
							String fin;
							if(jeu.aGagn�()){
								fin = "Gagn� !";
							}
							else{
								fin = "Perdu !";
								
							}
							System.out.println(fin);
							nbZombiesRestant.textProperty().unbind();
							nbZombiesRestant.setText(fin);
							

						}
						else{
							// Clear the canvas
							gc.clearRect(0, 0, jeu.getEnvironnement().getLargeurJardin(), jeu.getEnvironnement().nbreLigne()*100);
							Perso p;
							for (int i = 0; i < jeu.getEnvironnement().nbreLigne(); i++) {
								for (int j = 0; j < jeu.getEnvironnement().getLignePersos(i)
										.size(); j++) {
									p = jeu.getEnvironnement().getLignePersos(i).get(j);
									try{
									gc.drawImage(new Image(fichierImageDe(p)),p.getX(), (p.getLigne() * 100));
										}
									catch (IllegalArgumentException e){
										//Si image impossible � charger
										gc.drawImage(new Image("vue/unknown.png"),p.getX(), (p.getLigne() * 100));

									}

								}
							}
							for (int i = 0; i < jeu.getEnvironnement().getSoleils().size() ; i++) {
								Soleil s = jeu.getEnvironnement().getSoleils().get(i);
								gc.drawImage(new Image("vue/soleil.png"),s.getX(), (s.getLigne() * 100));
							}
							jeu.unTour();
						}
					}
				});


		gameLoop.getKeyFrames().add( kf );
		gameLoop.play();

		theStage.show();


	}

	/*
	 * Si this.plante � planter == la plante � selectionner --> Annule la selection
	 * Sinon met le type dans la plante s�lectionner dans this.plante � planter SI la cagnote est suffisante
	 * + Met le border
	 */
	private void selectionnerPlante(int nuPlante){
		int prixPlante;
		HBox boxABorder;
		switch (nuPlante){
		case 0: 
			prixPlante = prixPlante1;
			boxABorder = plante1Prix;
			break;

		case 1: 
			prixPlante = prixPlante2;
			boxABorder = plante2Prix;
			break;

		case 2: 
			prixPlante = prixPlante3;
			boxABorder = plante3Prix;
			break;

		case 3: 
			prixPlante = prixPlante4;
			boxABorder = plante4Prix;
			break;

		case 4: 
			prixPlante = prixPlante5;
			boxABorder = plante5Prix;
			break;

		default:
			throw new Error ("Plante inexistante");
		}

		if(jeu.getCagnote() >= prixPlante){
			if(planteAPlanter == nuPlante){
				planteAPlanter = -1;
				mettreBorder(null);
			}else{
				planteAPlanter = nuPlante;
				mettreBorder(boxABorder);
			}
		}
		else{
			planteAPlanter = -1;
			mettreBorder(null);
		}
		prixPlanteAPlanter = prixPlante;
	}

	/*
	 * SI aucune plante n'est pr�sente dans la case s�lectionn�e : 
	 * R�cup�re le type de la plante dans this.plante � planter
	 * Ajoute � l'environnement
	 * D�bite la cagnote
	 * Supprime le Border
	 * Supprime la plante s�lectionn�e
	 * */
	private void planter(int x, int y){
		x=(x/100)*100; //tronque la valeur � la centaine
		y=y/100;	   //R�cupere le num�ro de la ligne
		
		if(!jeu.getEnvironnement().estPresent(x, y)){
			switch (planteAPlanter){
			case 0: 
				jeu.getEnvironnement().ajoutPerso(new PistoPois(y, x, jeu.getEnvironnement()));
				break;
			case 1:
				jeu.getEnvironnement().ajoutPerso(new PlanteCactus(y, x, jeu.getEnvironnement()));
				break;
			case 2:
				jeu.getEnvironnement().ajoutPerso(new PlanteGroot(y, x, jeu.getEnvironnement()));
				break;
			case 3:
				jeu.getEnvironnement().ajoutPerso(new Tournesol(y, x, jeu.getEnvironnement()));
				break;
			case 4:
				jeu.getEnvironnement().ajoutPerso(new Noix(y, x, jeu.getEnvironnement()));
				break;
			default:
				throw new Error("Type de fleur innexistant");
			}

			jeu.setCagnote(jeu.getCagnote() - prixPlanteAPlanter );
			planteAPlanter = -1;
			mettreBorder(null);
		}
	}


	/*
	 * Applique un border sur le Hbox donn�
	 * Retire celui qui est � tous les autres
	 * 
	 * Si Hbox = null --> Supprime tous les border
	 * */
	private void mettreBorder(HBox plantePrix){

		for(HBox prix: listBox){
			if(plantePrix == null){
				prix.setBorder(null);
			}
			else{
				if(prix == plantePrix){
					plantePrix.setBorder(new Border(new BorderStroke(Color.RED, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(2))));
				}
				else{
					prix.setBorder(null);
				}
			}
		}

	}
	
	//Stoppe le programme
	private void arreterProgramme() {
		Platform.exit();
		System.exit(0);
	}


/*
 * Retourne le lien des images
 * */
	public String fichierImageDe(Perso p){

		if(p instanceof Noix){
			return "vue/cherrybomb.png";
		}
		else {
			if (p instanceof PlanteCactus) {
				return "vue/PlanteCactus.png";
			}
			else {
				if(p instanceof PistoPois){
					return "vue/peashooter.png";
				}
				else {
					if (p instanceof ZombieDeBase || 
							(p instanceof Perchiste && !((Perchiste) p).getASaPerche()) ||
							(p instanceof ZombieCasque && ((ZombieCasque)p).getgVie().estSansArmure()) ||
							(p instanceof ZombieMoustiquaire && ((ZombieMoustiquaire)p).getgVie().estSansArmure()) 
							) {
						return "vue/Zombie.png";
					}
					else{
						if (p instanceof ZombieCasque) {
							return "vue/ZombieCasque.png";
						}
						else{
							if (p instanceof Perchiste) {
								return "vue/Perchiste.png";
							}
							else {
								if (p instanceof ProjectileFleche) {
									return "vue/Fleche.png";
								}
								else {
									if (p instanceof PlanteGroot) {
										return "vue/PlanteGroot.png";
									}
									else {
										if(p instanceof ZombieMoustiquaire){
											return "vue/ZombieMoustiquaire.png";
										}
										else {
											if (p instanceof ZombieArcher){
												return "vue/ZombieArcher.png";
											}
											else{
												if (p instanceof Tournesol){
													return "vue/Sunflower.png";
												}
												else {
													if (p instanceof ZombieArcher) {
														return "vue/ZombieArcher.jpeg";
													} else {
														if( p instanceof Projectile){
															return "vue/pea.png";
														}			
														else {
															if ( p instanceof ZombieFutur){
																return "vue/ZombieFutur.png";
															} else {
																if ( p instanceof ZombieBombe){
																	return "vue/ZombieBombe.png";
																} else {
																	return "vue/unknown.png";
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
